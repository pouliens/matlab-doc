Run tenfold to get the evaluation results

run getDecisionTree(emotionNumber) to get a decision tree with the specified emotion

run getAllTrees() to get all trees in an array.